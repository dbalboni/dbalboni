
//----------------------------------------------------------------------
// Author:
// Assignment: 1
//----------------------------------------------------------------------

#include "stock.h"


Stock::Stock(std::string the_symbol) : Security(the_symbol)
{}


void Stock::set_purchase_price(double the_purchase_price)
{
  // TODO
}

double Stock::get_purchase_price() const
{
  // TODO
}

double Stock::sell_value() const
{
  // TODO
}

